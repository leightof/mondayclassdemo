

var quote = "one small step for man...";

function setup() {

	createCanvas(230, 220);

	textFont("Great Vibes");

	fill(0);

	stroke(255);

}


function draw () {

	background(102);

	textSize(16);

	text(quote, 25, 60, 200, 200);

}