
var img;

function preload() {

	img = loadImage("lunar.jpg");

}

function setup () {

	createCanvas(480, 420);

}

function draw () {

	image(img, 0, 0);
}