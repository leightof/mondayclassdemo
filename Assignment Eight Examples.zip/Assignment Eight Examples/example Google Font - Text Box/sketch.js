

function setup() {

	createCanvas(230, 220);

	textFont("Chango");

	fill(0);

	stroke(255);

}


function draw () {

	background(102);

	textSize(14);

	text("one small step for man...", 25, 60, 200, 200);

}